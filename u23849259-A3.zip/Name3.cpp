#include "Name3.h"

Name3::Name3(const std::string& userName) : Users(userName) {}
