#include "Name2.h"

Name2::Name2(const std::string& userName) : Users(userName) {}
