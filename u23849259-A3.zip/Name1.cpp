#include "Name1.h"

Name1::Name1(const std::string& userName) : Users(userName) {}
